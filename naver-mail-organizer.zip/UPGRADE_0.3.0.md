# 0.3.0 업데이트와 미확정 이동 복구

이 문서는 기존 NAS 서버를 업데이트하는 절차입니다. 패키지 수정은 완료했지만 현재 NAS·Cloudflare·ChatGPT에 원격 배포한 상태는 아닙니다. 모든 경로·폴더명은 예시이며 비밀 값은 포함하지 않습니다.

## 업데이트 전

1. 기존 예약과 다른 메일 정리 실행을 일시 중지합니다. 예약은 이 프로그램이 직접 생성하거나 중지하지 않습니다.
2. 기존 프로젝트 디렉터리와 Compose 프로젝트 이름을 확인합니다. 새로운 이름으로 프로젝트를 만들면 기존 named volume 대신 빈 볼륨이 연결될 수 있습니다.
3. 기존 소스, `server.env`, `tunnel.env`를 비공개 위치에 백업합니다. 설정 파일을 ZIP에 넣어 공유하지 않습니다.
4. SQLite DB는 서버를 멈춘 뒤 볼륨 전체를 백업합니다. 실행 중 DB 파일 하나만 복사하면 WAL의 기록이 빠질 수 있습니다. `docker compose down -v`는 사용하지 않습니다.

NAS SSH에서 실제 프로젝트 경로로 이동합니다.

```bash
cd /volume1/docker/naver-mail-organizer
sudo docker compose stop naver-mail-organizer
```

Container Manager에서 기존 프로젝트 볼륨을 확인하고 DSM 백업 도구로 백업합니다. `/data`에 `audit.sqlite3`, WAL/SHM 파일이 있으면 함께 보존합니다.

## 파일 교체와 시작

1. 이 패키지의 `server/`, `skills/`, `tests/`, 문서, `plugin.json`을 기존 프로젝트에 적용합니다.
2. 기존 `server.env`, `tunnel.env`, 실제 연결 설정 `mcp.json`은 덮어쓰지 않습니다.
3. 기존 Compose의 프로젝트명·볼륨·네트워크를 유지하고 서버 image 태그만 `naver-mail-organizer:0.3.0`으로 갱신합니다. NAS에서 조정한 다른 설정은 유지합니다.
4. `server.env`의 `NAVER_ALLOW_MOVE=false`로 먼저 시작합니다. 나머지 키·로그인·허용 목록은 유지합니다.

```bash
sudo docker compose up -d --build --no-deps naver-mail-organizer
sudo docker compose exec -T naver-mail-organizer python /app/probe.py tools
sudo docker compose exec -T naver-mail-organizer python /app/probe.py status
sudo docker compose exec -T naver-mail-organizer python /app/probe.py history
```

확인할 내용:

- 버전 `0.3.0`, 도구 10개, `post_move_verification=true`, `durable_move_journal=true`.
- 연결 성공, 기존 분류 폴더가 정확히 유지됨, 최초 `move_enabled=false`.
- 기존 `moved` 테이블이 `legacy_unverified`로 이관됨. 예전 테이블은 삭제하지 않음.
- Cloudflare 외부 주소와 Bearer 인증은 그대로 유지됨.

현재 ChatGPT 연결에서 도구 목록을 새로고침하거나 연결을 다시 불러옵니다. 일괄·검증 도구가 보이지 않으면 여전히 예전 도구 정의를 쓰는 것이므로 대량 이동을 재개하지 않습니다. 패키지 안의 skills도 플러그인의 기존 업데이트 경로로 반영해야 합니다. 서버 재빌드만으로 플러그인 지침까지 자동 갱신되지는 않습니다.

## 읽기 전용 확인

다음 요청으로 시작합니다.

```text
네이버 메일 정리 플러그인의 버전과 도구 10개를 확인해줘.
현재 폴더와 미확정 이동 이력을 확인하고,
읽은 메일 100건의 분류안만 작성해줘. 실제 이동은 하지 마.
필요한 본문만 최대 10건씩 묶어서 조회해줘.
목적이 모호하거나 본문 조회에 실패한 메일은 보류해줘.
```

목록에는 `metrics`가 포함됩니다. 같은 조건의 100건 조회에서 elapsed_ms, imap_commands, imap_ms_by_command, connection_reused를 비교합니다. 전체 FETCH·MOVE 횟수 감소와 실제 벽시계 시간 개선을 구분합니다. 도구 호출 사이 ChatGPT 판단 시간은 서버 elapsed_ms에 포함되지 않습니다.

## 소량 실제 이동 검증

1. 읽은 메일 중 목적지가 명확한 소수만 고릅니다. 별표가 있는 메일과 없는 메일을 포함합니다. 테스트를 위해 플러그인으로 별표를 변경하지 않습니다.
2. `NAVER_ALLOW_MOVE=true`로 저장하고 서버를 재생성합니다.

```bash
sudo docker compose up -d --no-deps --force-recreate naver-mail-organizer
sudo docker compose exec -T naver-mail-organizer python /app/probe.py status
```

3. 먼저 `naver_move_read_inbox_batch`의 `dry_run=true`로 해당 후보를 검사합니다.
4. 같은 후보만 `dry_run=false`로 이동합니다.
5. 각 항목에서 다음을 확인합니다.

| 필드 | 기대 값 |
| --- | --- |
| `status` | `verified` |
| `verified` | `true` |
| `details.source_absent` | `true` |
| `details.destination_found` | `true` |
| `details.identity_matches` | `true` |
| `details.seen_preserved` | `true` |
| `details.flagged_preserved` | `true` |
| `details.destination_not_deleted` | `true` |

6. `naver_verify_moves`로 다시 확인하고 네이버 웹에서도 목적지·읽음·별표를 대조합니다. 네이버 고유 중요 표시를 사용한다면 그것도 별도 확인합니다.
7. 성공 후에만 최대 50건씩 대량 이동합니다. 아직 불명확한 고객지원 알림이나 본문 실패 메일을 재분류하지 않고 보류합니다.

## 과거 감소량과 성공 수 구분

이전 실행에서 받은편지함 읽은 수가 감소했더라도 모두 성공한 이동으로 소급 집계하지 않습니다. 이전 `moved` 테이블에는 목적지 UID·이동 전후 플래그·메시지 지문이 없어 다음을 복원할 수 없습니다.

- 그때의 별표·읽음 상태가 지금 상태와 같은지
- 같은 제목·발신자의 여러 메일 중 어느 메일이 이동됐는지
- 명령 성공 뒤 DB 기록 전 단절된 메일이 몇 건인지

기록된 기존 작업은 `legacy_unverified`로 표시하고, 기록조차 없는 과거 이동은 자동 복원했다고 주장하지 않습니다. 과거 집계와 신규 0.3.0 검증 성공을 나눠 보고합니다. 현재 INBOX의 남은 읽은 메일은 새 후보로 조회해 처리할 수 있지만, 과거에 기록된 동일 후보는 자동 재이동하지 않습니다.

## 응답 단절과 부분 성공 복구

1. 신규 이동을 중단합니다. INBOX 건수만 보고 이동 수를 계산하지 않습니다.
2. `naver_get_move_results(needs_attention=true, after_id=0)`로 미확정 기록을 조회합니다. `has_more=true`면 `next_after_id`를 이어갑니다. 이 도구는 네이버 접속이 실패해도 DB를 읽을 수 있습니다.
3. 응답의 `handle`을 최대 50개씩 `naver_verify_moves(handles=[...])`에 넘깁니다. 실제 메일을 바꾸는 명령은 보내지 않습니다.
4. 원본 부재·목적지 식별·플래그 대조를 완료한 작업만 verified로 집계합니다. 작업 ID로 중복 제거합니다.
5. 원본이 남아 있거나 목적지가 불명확하면 unresolved를 유지합니다. 같은 MOVE를 자동 반복하지 않습니다. 두 폴더를 직접 대조하고 관리자 판단으로 처리합니다. DB 행 삭제·키 교체·COPY+삭제로 우회하지 않습니다.
6. `verification_failed`가 있으면 상태를 자동 수리하지 말고 원인을 조사합니다.

로컬 진단으로도 검증할 수 있습니다. 실제 핸들은 비공개 터미널에서만 다루며 아래 자리표시자를 그대로 실행하지 않습니다.

```bash
sudo docker compose exec -T naver-mail-organizer python /app/probe.py verify <<'JSON'
{"handles":["<candidate-handle>"]}
JSON
```

`probe.py history`는 기본 100건의 미확정 이력 첫 페이지입니다. 전체 이력 열거는 MCP의 커서와 has_more를 사용합니다.

## 집계 규칙

- 신규 이동: 해당 실행에서 `newly_verified=true`인 operation_id의 고유 개수.
- 복구 확인: pending/unresolved였던 작업을 재검증해 verified로 확인한 고유 개수. 이전 성공과 중복 합산하지 않음.
- 계정 전체 검증 현황: `naver_get_move_results`의 `totals`. 현재 DB 기록 기준이며 이번 실행 결과와 다름.
- 미확정·legacy·보류·실패·미검토: 각각 별도로 보고.

수신함의 읽은 수는 다른 앱 사용이나 새 메일 읽음 처리로도 바뀔 수 있습니다. 전후 차이를 공식 이동 성공 건수로 사용하지 않습니다.

## 롤백

문제가 있으면 먼저 `NAVER_ALLOW_MOVE=false`로 재생성하고 예약을 중지합니다. 코드 롤백은 가능하지만 0.2.0은 새 journal을 이해하지 못합니다. 0.3.0 배포 후의 DB를 그대로 0.2.0에서 사용해 쓰기를 재개하면 새 이력을 놓칠 수 있으므로 금지합니다. 이동은 네이버에 이미 반영된 외부 변경이므로 DB 백업 복원만으로 되돌아가지 않습니다. DB와 실제 폴더 상태를 대조한 뒤 복구합니다.
