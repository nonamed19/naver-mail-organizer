# 0.4.0 광고 메일 스팸함 이동

기존 0.3.0 서버 소스를 기반으로 추가한 기능입니다. NAS에 실행 중인 소스와 별도 변경 사항이 있다면 교체 전 비교하세요.

## 변경 파일

- `server/server.py`: 스팸함 탐색, 상태 정보, 전용 일괄 이동 도구, 재검증 지원.
- `server.env.example`: 스팸 이동 활성화 및 목적지 설정 예시.
- `skills/organize-read-mail/SKILL.md`: 제목·본문 기반 광고 판단 및 전용 실행 절차.
- `plugin.json`, `compose.yaml`: 버전 0.4.0.
- `tests/test_server.py`, `tests/test_http.py`: 스팸 이동 검증 및 도구 목록 변경.
- `README.md`, `TEST_RESULTS.md`, 이 문서: 사용·검증·업데이트 안내.

## 동작 범위

ChatGPT가 제목과 필요한 본문을 읽어 광고 여부를 판단합니다. Python 서버 자체에 AI 모델이나 키워드 자동 분류기는 추가하지 않았습니다. 명확한 광고 메일의 서명된 핸들을 `naver_move_read_inbox_to_spam_batch`에 전달하면, 서버가 결정한 기존 스팸함으로만 최대 50건을 이동합니다. 기존 읽은 INBOX 메일만 대상으로 하며 미열람 메일이나 기존 분류 폴더는 검색·이동하지 않습니다.

스팸 신고, 발신자 차단, 구독 해지, 삭제, 폴더 생성은 수행하지 않습니다. IMAP MOVE 이후 네이버 자체 정책으로 발생하는 후속 처리나 보관 기간은 이 코드가 제어하지 않습니다.

## NAS 적용

1. 기존 프로젝트와 `server.env`를 백업합니다. 실제 비밀정보가 들어 있는 `server.env`, `tunnel.env` 및 기존 `mail-data` 볼륨을 유지합니다.
2. ZIP의 변경 파일을 기존 `/volume1/06_Server/naver-mail-organizer`에 반영합니다. 예제 환경 파일로 실제 환경 파일을 덮어쓰지 않습니다.
3. 우선 `server.env`에 아래를 추가합니다.

```dotenv
NAVER_ALLOW_SPAM_MOVE=false
NAVER_SPAM_FOLDER=
```

4. SSH에서 재빌드합니다.

```bash
cd /volume1/06_Server/naver-mail-organizer
sudo docker compose up -d --build naver-mail-organizer
sudo docker compose logs --tail=50 naver-mail-organizer
```

5. ChatGPT 연결의 도구 목록을 갱신하거나 재연결합니다. `naver_status`의 `server_version=0.4.0`, `spam_folder`를 확인합니다. `spam_folder`가 null이면 IMAP에서 실제 노출되는 스팸함 이름을 확인해 `NAVER_SPAM_FOLDER`에 입력합니다. 한국어 표시명만으로 임의 추정하거나 새 폴더를 만들지 않습니다. 명시 설정은 실제 스팸함을 가리키는지 운영자가 확인해야 합니다.
6. 광고 후보로 `naver_move_read_inbox_to_spam_batch(handles=[...], dry_run=true)`를 실행합니다. 미리보기는 서버 이동 권한·읽음 상태·목적지를 검사하며 광고 판단을 대신하지 않습니다.
7. 목적지가 맞으면 `server.env`에 `NAVER_ALLOW_MOVE=true`, `NAVER_ALLOW_SPAM_MOVE=true`를 설정하고 컨테이너를 위 명령으로 재생성합니다. 기존 일반 분류의 이동 권한이 켜져 있다면 별도 스팸 권한만 추가하면 됩니다.
8. 소량 실제 이동을 요청해 `verified=true`, 원본 부재, 목적지 동일성, 읽음·별표 보존을 확인합니다. 실계정 확인이 끝나기 전 대량 처리 완료로 간주하지 않습니다.
9. ChatGPT의 플러그인 지침에도 수정된 SKILL.md를 반영합니다. NAS 서버를 재빌드하는 것만으로 클라우드 플러그인 지침이 바뀌지는 않습니다. 기존 계정 연결·플러그인 ID는 유지합니다.

## 실행 예시

> 받은편지함의 읽은 메일에서 제목과 필요한 본문을 확인해 명확한 광고 메일만 기존 스팸함으로 옮겨줘. 주문·배송·예약·영수증·결제·인증·보안·업무 연락은 보호하고, 애매하거나 본문 조회에 실패하면 보류해줘. naver_status로 스팸 목적지와 권한을 확인하고 전용 스팸 이동 도구를 사용해줘. 이동 후 상태 보존 검증 결과를 집계해줘.

이번 변경은 코드를 제공하는 작업이며 실제 계정의 광고 메일을 이동하거나 NAS에 배포하거나 예약을 생성하지 않습니다.
