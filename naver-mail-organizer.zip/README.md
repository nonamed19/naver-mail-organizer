# 네이버 메일 정리 플러그인 0.3.0

![Python](https://img.shields.io/badge/Python-3.11%2B-3776AB?logo=python&logoColor=white)
![Docker](https://img.shields.io/badge/Docker-2496ED?logo=docker&logoColor=white)
![Cloudflare](https://img.shields.io/badge/Cloudflare_Tunnel-F38020?logo=cloudflare&logoColor=white)

Synology NAS의 Python IMAP 서버와 ChatGPT 분류 지침으로 네이버 INBOX의 **읽은 메일**을 기존 폴더에 정리합니다. 서버는 Python 표준 라이브러리만 사용하며, 분류 판단은 ChatGPT가 수행합니다. 별도 OpenAI API 키는 필요하지 않습니다.

신규 설치는 [SYNOLOGY_SETUP.md](SYNOLOGY_SETUP.md), 기존 서버의 업데이트·복구는 [UPGRADE_0.3.0.md](UPGRADE_0.3.0.md)를 따릅니다. 소스 업로드만으로 현재 NAS 서버·연결된 플러그인·예약이 갱신되지는 않습니다.

## 개선한 내용

| 항목 | 0.2.0 | 0.3.0 |
| --- | --- | --- |
| 목록 조회 | 기본 30건·최대 100건, 메일마다 FETCH | 기본 100건·최대 200건, 100 UID씩 일괄 FETCH |
| IMAP 접속 | 호출마다 로그인·종료 | 최대 2개 연결을 배타적으로 재사용, 유휴 120초 후 다음 사용 시 교체 |
| MOVE 기능 감지 | 로그인 전 capability가 남을 수 있음 | 로그인 후 CAPABILITY 갱신 |
| 본문 도구 | 한 건씩 호출 | 기존 도구 + 최대 10건 본문 조회 도구, 내부 본문은 순차 처리 |
| 메일 이동 | 한 건씩 도구 호출 | 최대 50건 요청, 목적지별 UID MOVE |
| 이동 결과 | 명령 OK와 이동 전 flags만 반환 | 원본 부재·목적지 식별·읽음·별표 보존 대조 |
| 결과 저장 | 이동 명령 이후 성공 이력만 기록 | MOVE 전에 SQLite에 검증 근거를 커밋 |
| 응답 단절 | 실제 이동과 성공 이력 사이 공백 가능 | pending 기록을 읽기 전용 재검증, 자동 재이동 금지 |
| 집계 | 폴더 건수 변화와 혼동 가능 | 작업 ID별 결과·신규 검증 수·이력 조회·상태별 전체 합계 |

기존 스킬의 `limit=50`과 기본 최대 200건 검토 지침도 갱신했습니다. 전체 처리를 명시하면 페이지를 이어가고, 예약의 기본 검토 범위는 여전히 200건입니다.

## 구성

| 구성 | 역할 |
| --- | --- |
| `server/server.py` | 인증, IMAP, MCP 10개 도구, SQLite 이동 기록 |
| `server/probe.py` | 로컬 상태·도구·미확정 이력·재검증 진단 |
| `server/configure_endpoint.py` | 실제 HTTPS 주소의 도구 목록 검증 후 연결 설정 생성 |
| `compose.yaml` | 서버와 선택적 cloudflared, 기존 `/data` 볼륨 유지 |
| `skills/organize-read-mail/` | 일괄 처리·검증·결과 집계 지침 |
| `tests/` | 모의 IMAP과 로컬 HTTP 테스트, 외부 서비스 접근 없음 |

ChatGPT의 HTTPS 요청은 Cloudflare Tunnel을 통해 NAS 서버의 `/mcp`로 전달되고, 서버는 `imap.naver.com:993`에 연결합니다. 본문 등 도구 응답은 Cloudflare를 경유해 ChatGPT에 전달되므로 데이터가 NAS 안에서만 처리되는 구조는 아닙니다.

## 도구와 사용 예

| 도구 | 입력과 동작 |
| --- | --- |
| `naver_status` | 연결·버전·MOVE·일괄 처리·검증 기능 확인 |
| `naver_list_folders` | 실제 존재하는 허용 분류 폴더 조회 |
| `naver_list_read_inbox` | `limit=100`, `after_uid=0`; 최대 200건, 커서 반환 |
| `naver_sample_folder` | `folder`, `limit=3`; 최대 10건의 참고 헤더 |
| `naver_read_message` | `handle`; 기존 단건 본문 조회 |
| `naver_read_messages` | `handles`; 최대 10건, 건별 오류 반환 |
| `naver_move_read_inbox` | `handle`, `destination`; 기존 입력 유지, 검증된 경우 status=verified |
| `naver_move_read_inbox_batch` | `items`, `dry_run`; 최대 50건, **dry_run 기본 true** |
| `naver_verify_moves` | `handles`; 최대 50건의 이동 기록을 IMAP 읽기로 재검증 |
| `naver_get_move_results` | `after_id=0`, `limit=100`, `needs_attention=false`; DB 이력 조회, 네이버 연결 불필요 |

일괄 이동 입력:

```json
{
  "items": [
    {"handle": "<candidate-handle-1>", "destination": "<existing-folder>"},
    {"handle": "<candidate-handle-2>", "destination": "<existing-folder>"}
  ],
  "dry_run": true
}
```

실제 이동은 사용자 요청 범위에서 `NAVER_ALLOW_MOVE=true`이고 `dry_run=false`일 때만 실행합니다. 목적지 폴더는 새로 만들지 않습니다. 같은 후보가 기록에 있으면 목적지를 바꿔 재전송하지 않고 기존 결과를 확인합니다.

반환 결과의 핵심 필드:

| 필드 | 의미 |
| --- | --- |
| `operation_id` | 영속 기록의 작업 ID. 집계와 재시도 중복 제거 기준 |
| `status`, `verified` | 검증 상태. 명령 OK만으로 true가 되지 않음 |
| `flags_before`, `details.flags_after` | 이동 직전과 목적지 FLAGS |
| `details.source_absent` | 원본 INBOX에서 해당 UID 부재 |
| `details.identity_matches` | 목적지 메일의 헤더·크기 지문 일치 |
| `details.seen_preserved`, `details.flagged_preserved` | 읽음·별표 대조 |
| `destination_handle` | 식별된 목적지 메일을 읽기 위한 서명 핸들 |
| `newly_verified_count` | 해당 이동 요청에서 신규로 검증 완료한 수. 재생 요청은 0 |
| `verified_count` | 해당 응답의 verified 수. 이전 성공의 재확인을 포함할 수 있음 |
| `metrics` | 서버 소요 ms·IMAP 명령 수·명령별 ms·연결 재사용 여부. 연결·로그인·CAPABILITY 초기 비용은 전체 소요 시간에만 포함 |

`counts`는 요청 항목별 상태이고, 이력 도구의 `totals`는 계정의 DB 전체 작업 합계입니다. 이번 실행 수와 혼합하지 않습니다. `after_id`는 신규 작업을 열거하는 커서로, 이전 작업의 상태 변경을 추적하는 이벤트 커서는 아닙니다. 복구 시 0부터 다시 조회합니다.

## 이동 검증과 재시도

1. 서명·계정·허용 목적지·INBOX·읽음·삭제 플래그·UIDVALIDITY를 검사합니다.
2. 목적지 UIDVALIDITY와 UIDNEXT, 원본 헤더·크기 지문·직전 FLAGS를 SQLite에 저장하고 커밋합니다.
3. 목적지별로 검증된 UID 집합을 MOVE합니다.
4. COPYUID가 있으면 원본→목적지 UID 대응을 사용합니다.
5. COPYUID가 없거나 응답이 단절되면 저장한 UIDNEXT 이후의 신규 UID를 최대 200건 확인합니다. 헤더·크기 지문이 유일하게 일치할 때만 목적지로 식별합니다.
6. 원본 부재, 목적지 지문, `\Seen`, `\Flagged`, 목적지 `\Deleted` 부재를 확인한 경우에만 verified로 기록합니다.

COPYUID가 없는 경우의 지문은 선택된 헤더와 메시지 크기 기반이며 원문 전체의 바이트 동일성을 증명하지 않습니다. 중복·검색 범위 초과·UIDNEXT 없음·UIDVALIDITY 변경 등 근거 부족 상황은 unresolved로 남깁니다. 네이버 고유 중요 표시나 모든 사용자 정의 플래그의 보존은 이 검증 범위에 포함하지 않습니다.

| 상태 | 의미·처리 |
| --- | --- |
| `preview` | 읽기 전용 검사 완료. 이동하지 않음 |
| `verified` | 원본·목적지·읽음·별표 검증 완료 |
| `pending` | 이동 전 기록은 있지만 응답 또는 검증 미완료. 재검증 필요 |
| `unresolved` | 실제 이동 여부 또는 동일성 확인이 불충분. 신규 이동 중단·관리자 확인 |
| `verification_failed` | 목적지 메일의 읽음·별표 또는 삭제 상태 대조 실패. 이동 중단 |
| `legacy_unverified` | 이전 DB에 성공 기록만 있고 검증 근거 없음 |
| `rejected` | 검증 조건 실패. 해당 항목 이동하지 않음 |
| `not_attempted` | 앞선 문제로 해당 항목의 MOVE 미실행 |
| `not_recorded` | 재검증 요청 대상의 DB 기록 없음. 성공·실패를 단정하지 않음 |

한 묶음이 부분 성공했을 때 전체를 하나의 성공으로 표현하지 않습니다. 일괄 MOVE는 완전한 트랜잭션이 아닙니다. 불명확한 결과가 생기면 나머지 목적지 그룹의 이동을 중단합니다. 별표 불일치를 고치려고 STORE 명령을 보내지 않습니다.

동일 핸들로 다시 이동 요청하면 기존 기록의 읽기 전용 검증만 수행하며 MOVE를 재발행하지 않습니다. 원본이 남아 있는 unresolved도 자동 재이동하지 않으므로 관리자 확인이 필요합니다. DB를 삭제하거나 키를 바꿔 재시도하지 않습니다.

## 검증과 성능 범위

```bash
python -m unittest discover -s tests -v
```

모의 IMAP 및 로컬 HTTP에서 정상·부분 성공·플래그 유실·응답 단절·중복·UIDVALIDITY 변경·예전 DB 이관을 검사합니다. 테스트에서 100건 목록의 헤더 FETCH 1회, 같은 목적지 묶음의 MOVE 1회가 확인됩니다. 실서비스에서 몇 배 빨라지는지 측정한 수치는 아닙니다.

실제 Docker 빌드·NAS 배포·네이버의 COPYUID 응답·Cloudflare 연결·ChatGPT 도구 새로고침·예약 실행은 이 패키지의 로컬 테스트로 보증하지 않습니다. `/healthz`는 프로세스 상태이며 네이버 로그인 성공을 뜻하지 않습니다.

## 동작 경계

- 메일 발송, 폴더 생성·변경·삭제, EXPUNGE, COPY+삭제 우회, 플래그 변경 도구를 제공하지 않습니다.
- 본문은 크기 검사 후 최대 5 MiB 원문을 읽고 최대 20,000자를 반환합니다. 큰 메시지는 보류합니다. 첨부파일 내용을 분석하지 않습니다.
- 본문 실패 후보나 목적이 모호한 메일을 자동 분류하거나 억지로 이동하지 않습니다.
- 단일 계정·단일 소유자·서버 프로세스 하나를 전제로 합니다. 여러 복제본에서 같은 DB·IMAP 계정을 동시에 변경하는 운영은 지원하지 않습니다.
- 서버가 검사한 직후 다른 메일 앱이 상태를 변경할 수 있습니다. 대량 처리 중 다른 정리 작업과 동시 실행하지 않습니다.
- 실제 비밀 설정과 메일 데이터는 포함하지 않습니다. 배포 시 기존 `server.env`, `tunnel.env`, `/data`를 유지합니다.

공식 참고: [네이버 IMAP](https://help.naver.com/service/30029/contents/21344), [Cloudflare Tunnel](https://developers.cloudflare.com/tunnel/get-started/), [IMAP RFC 9051](https://www.rfc-editor.org/rfc/rfc9051.html).

## 0.4.0: 광고 메일의 스팸함 이동

ChatGPT가 제목·필요한 본문으로 광고 여부를 판단하고, 전용 `naver_move_read_inbox_to_spam_batch`로 최대 50건씩 기존 스팸함에 이동합니다. 읽은 INBOX만 대상으로 하며 거래·보안·업무 메일과 불명확한 후보를 보호합니다. 서버는 IMAP `\\Junk` 또는 운영자가 설정한 정확한 기존 메일함을 확인합니다. 별도 `NAVER_ALLOW_SPAM_MOVE` 권한이 필요하고 dry_run은 기본 true입니다. 스팸 신고·발신자 차단 기능은 포함하지 않습니다.

배포와 지침 적용 방법은 [0.4.0 업데이트 안내](UPGRADE_0.4.0.md)를 확인하세요. 아래의 이전 버전 안내·테스트 기록은 해당 버전의 기록입니다.
